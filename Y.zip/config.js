import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import moment from 'moment-timezone'

/*============= WAKTU =============*/
let wibh = moment.tz('Asia/Makassar').format('HH')
    let wibm = moment.tz('Asia/Makassar').format('mm')
    let wibs = moment.tz('Asia/Makassar').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
    
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
         
/*============== SOCIAL ==============*/
global.sig = 'https://instagram.com/' //instagram
global.sgh = 'https://github.com/WayanGledy' //github
global.sgc = 'https://whatsapp.com/channel/0029Vae6RZx2Jl8CNqYqbW2g' //group whatsapp
global.saluran = 'https://whatsapp.com/channel/0029Vae6RZx2Jl8CNqYqbW2g' //saluran whatsapp
global.syt = 'https://www.youtube.com/@mrtermux' //youtube
global.swa = 'https://wa.me/6283834202329' //whatsapp
global.tele = 'https://t.me/WayanGledy' //telegram
global.sdc = '-' //discord
global.snh = '-' //nhentai

/*============== PAYMENT ==============*/
global.pdana = '6283834202329' //pulsa1
global.ppulsa = '6283834202329' //pulsa2
global.povo = '6283834202329' //ovo
global.gopay = '6283834202329' //gopay
global.dana = '6283834202329' //dana
global.sid = 's.id' //s.id
global.psaweria = '-' //saweria

/*============== NOMOR ==============*/
global.nomorwa = '6283834202329' //whatsapp
global.nomorbot = '6283834202329' //nomor Bot
global.nomorown = '6283834202329' //nomor Owner
global.namebot = 'YP - AI' //nama Bot
global.nameown = 'YP - AI' //nama Owner

/*============== STAFF ==============*/
global.owner = [
  ['6283834202329', 'Aero', true] //creator/owner
] //put your number here
global.mods = ['6283834202329'] //moderator
global.prems = ['6283834202329'] //prem bukan disini

/*============== CPANEL ==============*/
global.domain = 'https://xxxxx' //domain nya
global.capikey = 'pltc_xxxxx' //pltc
global.apikey = 'plta_xxxxx' //plta

/*============== APIKEY ==============*/
global.lolkey = '57b9675ff6e37b13e50282e9'
global.xkey = 'd90a9e986e18778b'
global.xzn = 'naufalyp'
global.lann = 'p8ADYJib'
global.xyro = '3WIq7q3CWt'

/*============== API ==============*/
global.APIs = { // API Prefix
  // name: 'https://website'
  nrtm: 'https://nurutomo.herokuapp.com',
  lol: 'https://api.lolhuman.xyz', 
  xzn: 'https://skizo.tech',
  lann: 'https://api.betabotz.org', 
  xyro: 'https://api.xyroinee.xyz'
}

global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.lolhuman.xyz': 'naufalYP', //lolhuman
  'https://skizo.tech': 'naufalyp', //skizo
  'https://api.betabotz.org': 'p8ADYJib', //betabotz
  'https://api.xyroinee.xyz': '3WIq7q3CWt' //xyroine
}

/*============== VERSION ==============*/
global.version = 'Beta V17.8'

/*============== WATERMARK ==============*/
global.wm = 'Naufal YP X Karina Botsz' //wm1
global.wm2 = 'YP - AI' //wm2
global.wm3 = 'YP - AI' //wm3
global.namedoc = 'YP - AI' //nama document
global.botdate = `DAYS: ${week} ${date}`
global.bottime = `TIME: ${wktuwib}`
global.titlebot = 'YP - AI'
global.author = global.wm

/*============== THUMB ==============*/
global.elaina = 'https://telegra.ph/file/88f49222b5a8666be7356.jpg'

/*============== LOGO ==============*/
global.thumb = 'https://telegra.ph/file/88f49222b5a8666be7356.jpg' //thumbnail
global.thumb2 = 'https://telegra.ph/file/88f49222b5a8666be7356.jpg'
global.thumbbc = 'https://telegra.ph/file/88f49222b5a8666be7356.jpg' //broadcast
global.giflogo = 'https://telegra.ph/file/40f025b60268bf3fbed04.mp4'
global.thumblvlup = 'https://telegra.ph/file/88f49222b5a8666be7356.jpg'
global.hwaifu = ['https://telegra.ph/file/88f49222b5a8666be7356.jpg']

/*============== FlamingText ===========*/
global.flaaa = [
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=', 
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=',
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=',
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=',
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text='] 

/*============== TEXT ==============*/
global.wait = 'Loading....'
global.eror = '```404 error```'
global.dtu = 'ɪɴꜱᴛᴀɢʀᴀᴍ'
global.dtc = 'ᴄᴀʟʟ ᴏᴡɴᴇʀ'
global.phn = '+6283834202329'

/*=========== TYPE DOCUMENT ===========*/
global.dpptx = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.ddocx = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.dxlsx = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.dpdf = 'application/pdf'
global.drtf = 'text/rtf'
global.djson = 'application/json'

global.thumbdoc = 'https://telegra.ph/file/4379fbc156dbd87dde14a.jpg'

/*=========== FAKE SIZE ===========*/
global.fsizedoc = '9' // default 10TB
global.fpagedoc = '9'

/*=========== HIASAN ===========*/
// DEFAULT MENU
global.dmenut = '––––––––––' //top
global.dmenub = '┊>' //body
global.dmenub2 = '┊>' //body for info cmd on Default menu
global.dmenuf = '––––––––––' //footer

// COMMAND MENU
global.dashmenu = '––––––––––'
global.cmenut = '––––––––––'                       //top
global.cmenuh = '––––––––––'                        //header
global.cmenub = '┊>'                            //body
global.cmenuf = '––––––––––\n'                //footer
global.cmenua = '\n⌕––––––––––⌕\n     ' //after
global.pmenus = '┊>'                              //pembatas menu selector

global.htki = '––––––––––' // Hiasan Titile (KIRI)
global.htka = '––––––––––' // Hiasan Title  (KANAN)
global.lopr = 'Ⓟ' //LOGO PREMIUM ON MENU.JS
global.lolm = 'Ⓛ' //LOGO LIMIT/FREE ON MENU.JS
global.htjava = '<>'    //hiasan
global.hsquere = ['⛶','❏','⫹⫺']

/*============== STICKER WM ==============*/
global.stickpack = 'YP - AI'
global.stickauth = `YP - AI`
global.packname = 'YP - AI'
global.packname2 = 'YP - AI'

global.multiplier = 38 // The higher, The harder levelup

/*============== EMOJI ==============*/
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            Fox: "🦊",
            agility: "🤸‍♂️",
            anggur: "🍇",
            apel: "🍎",
            aqua: "🥤",
            arc: "🏹",
            armor: "🥼",
            bank: "🏦",
            batu: "🧱",
            berlian: "💎",
            bibitanggur: "🍇",
            bibitapel: "🍎",
            bibitjeruk: "🍊",
            bibitmangga: "🥭",
            bibitpisang: "🍌",
            botol: "🍾",
            bow: "🏹",
            bull: "🐃",
            cat: "🐈",
            centaur: "🎠",
            chicken: "🐓",
            coal: "⚱️",
            common: "📦",
            cow: "🐄",
            crystal: "🔮",
            darkcrystal: "♠️",
            diamond: "💎",
            dog: "🐕",
            dragon: "🐉",
            eleksirb: "🧪",
            elephant: "🐘",
            emasbatang: "🪙",
            emasbiasa: "🥇",
            emerald: "💚",
            exp: "✉️",
            fishingrod: "🎣",
            foodpet: "🍱",
            fox: "🦊",
            gardenboc: "🗳️",
            gardenboxs: "📦",
            gems: "🍀",
            giraffe: "🦒",
            gold: "👑",
            griffin: "🦒",
            health: "❤️",
            healtmonster: "❤‍🔥",
            horse: "🐎",
            intelligence: "🧠",
            iron: "⛓️",
            jeruk: "🍊",
            kaleng: "🥫",
            kardus: "📦",
            kayu: "🪵",
            ketake: "💿",
            keygold: "🔑",
            keyiron: "🗝️",
            knife: "🔪",
            koinexpg: "👛",
            kucing: "🐈",
            kuda: "🐎",
            kyubi: "🦊",
            legendary: "🗃️",
            level: "🧬",
            limit: "🌌",
            lion: "🦁",
            magicwand: "⚕️",
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            mana: "🪄",
            mangga: "🥭",
            money: "💵",
            mythic: "🗳️",
            mythic: "🪄",
            naga: "🐉",
            pancingan: "🎣",
            pet: "🎁",
            petFood: "🍖",
            phonix: "🦅",
            pickaxe: "⛏️",
            pisang: "🍌",
            pointxp: "📧",
            potion: "🥤",
            rock: "🪨",
            rubah: "🦊",
            sampah: "🗑️",
            serigala: "🐺",
            snake: "🐍",
            stamina: "⚡",
            strength: "🦹‍♀️",
            string: "🕸️",
            superior: "💼",
            sword: "⚔️",
            tiger: "🐅",
            tiketcoin: "🎟️",
            trash: "🗑",
            umpan: "🪱",
            uncommon: "🎁",
            upgrader: "🧰",
            wood: "🪵"
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, "gi")]).filter(v => v[1].test(string))
        if (!results.length) return ""
        else return emot[results[0][0]]
    }
}


//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
